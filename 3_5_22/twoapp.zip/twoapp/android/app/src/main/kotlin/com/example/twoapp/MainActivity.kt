package com.example.twoapp

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
