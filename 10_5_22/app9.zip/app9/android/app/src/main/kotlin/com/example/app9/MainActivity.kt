package com.example.app9

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
